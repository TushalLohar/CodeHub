import * as store from "./storage.js";
import { createPacer } from "./pace.js";
const GFG_API = "https://practiceapi.geeksforgeeks.org/api/vr/user/problems/submissions/";
const REQUEST_TIMEOUT = 15_000;
const DIFFICULTIES = ["School", "Basic", "Easy", "Medium", "Hard"];
const EXT_BY_LANG = {
    cpp: "cpp",
    "c++": "cpp",
    "c++14": "cpp",
    "c++17": "cpp",
    "c++20": "cpp",
    c: "c",
    java: "java",
    java8: "java",
    java11: "java",
    python: "py",
    python3: "py",
    py: "py",
    py3: "py",
    javascript: "js",
    js: "js",
    typescript: "ts",
    ts: "ts",
    csharp: "cs",
    "c#": "cs",
    golang: "go",
    go: "go",
    rust: "rs",
    kotlin: "kt",
    php: "php",
    ruby: "rb",
    swift: "swift",
};
function extFor(language) {
    if (!language)
        return "cpp";
    const cleaned = language.toLowerCase().replace(/[^a-z0-9+#]/g, "");
    return EXT_BY_LANG[cleaned] || EXT_BY_LANG[language.toLowerCase()] || "cpp";
}
function sanitizeName(name) {
    return ((name || "Problem")
        .replace(/[\\/:*?"<>|]/g, "-")
        .replace(/[\u0000-\u001f]/g, "")
        .replace(/\s+/g, " ")
        .replace(/\.+$/, "")
        .trim()
        .slice(0, 80) || "Problem");
}
function normalizeDifficulty(diff) {
    const lower = String(diff || "")
        .toLowerCase()
        .trim();
    const hit = DIFFICULTIES.find((d) => d.toLowerCase() === lower);
    return hit || "Easy";
}
function keyFor(sub) {
    return sanitizeName(sub.title || sub.name || sub.slug || String(sub.id));
}
export function submissionIdFor(slug, source) {
    let hash = 5381;
    const text = String(source || "");
    for (let i = 0; i < text.length; i += 1) {
        hash = ((hash << 5) + hash + text.charCodeAt(i)) | 0;
    }
    return `${slug || "problem"}:${(hash >>> 0).toString(36)}`;
}
function transientError(message, retryAfterMs) {
    const err = new Error(message);
    err.code = "transient";
    if (retryAfterMs)
        err.retryAfter = retryAfterMs;
    return err;
}
const pacer = createPacer({ min: 250, max: 8000 });
const { paced, noteOutcome, throttleBackoffMs } = pacer;
async function api(body) {
    return paced(async () => {
        let res;
        try {
            res = await fetch(GFG_API, {
                method: "POST",
                credentials: "include",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(body),
                signal: AbortSignal.timeout(REQUEST_TIMEOUT),
            });
        }
        catch (e) {
            noteOutcome(false);
            if (e.name === "TimeoutError" || e.name === "AbortError") {
                throw transientError("GeeksforGeeks request timed out — will retry");
            }
            throw transientError(`GeeksforGeeks request failed (${e.message}) — will retry`);
        }
        if (res.status === 406 || res.status === 404) {
            throw new Error(`GeeksforGeeks user "${body.handle}" not found — check the username`);
        }
        if (res.status === 429 || res.status >= 500) {
            noteOutcome(false);
            const retryAfter = Number(res.headers.get("retry-after") || 0) * 1000;
            throw transientError(`GeeksforGeeks is busy (${res.status}) — slowing down`, retryAfter || throttleBackoffMs(res));
        }
        if (!res.ok)
            throw new Error(`GeeksforGeeks API returned HTTP ${res.status}`);
        noteOutcome(true);
        return res.json();
    });
}
export async function handleExists(handle) {
    if (!handle)
        return false;
    try {
        await api({ handle: handle.trim(), request_type: "solved", page: 1 });
        return true;
    }
    catch {
        return true;
    }
}
export async function checkSession() {
    const config = await store.getConfig();
    if (!config?.gfgHandle)
        return { ok: true, error: null };
    if (chrome.cookies?.getAll) {
        try {
            const cookies = await chrome.cookies.getAll({ domain: "geeksforgeeks.org" });
            const signedIn = cookies.some((c) => c.value &&
                ["gfg_id", "gfg_session", "auth_token", "gfguser", "gfg_username", "sessionid"].includes(c.name));
            if (signedIn)
                return { ok: true, error: null };
        }
        catch {
        }
    }
    if (chrome.tabs?.query) {
        try {
            const tabs = await chrome.tabs.query({ url: ["*://*.geeksforgeeks.org/*"] });
            if (tabs.length)
                return { ok: true, error: null };
        }
        catch {
        }
    }
    return { ok: false, error: "Sign in to GeeksforGeeks so SolveBase can read your solutions" };
}
export async function readEditorFromTab(tabId) {
    if (!Number.isInteger(tabId) || !chrome.scripting?.executeScript)
        return null;
    try {
        const frames = await chrome.scripting.executeScript({
            target: { tabId },
            world: "MAIN",
            func: () => {
                const usable = (value) => typeof value === "string" && value.trim().length > 10 ? value : null;
                try {
                    for (const model of window.monaco?.editor?.getModels?.() || []) {
                        const value = usable(model.getValue?.());
                        if (value)
                            return value;
                    }
                }
                catch {
                }
                try {
                    if (window.ace?.edit) {
                        for (const el of document.querySelectorAll(".ace_editor")) {
                            const value = usable(window.ace.edit(el).getValue());
                            if (value)
                                return value;
                        }
                    }
                }
                catch {
                }
                try {
                    for (const el of document.querySelectorAll(".CodeMirror")) {
                        const value = usable(el.CodeMirror?.getValue?.());
                        if (value)
                            return value;
                    }
                }
                catch {
                }
                return null;
            },
        });
        return frames?.[0]?.result || null;
    }
    catch {
        return null;
    }
}
function requestSubmissionsInPage(slug) {
    const urls = [
        `https://practiceapi.geeksforgeeks.org/api/latest/problems/${slug}/submissions/`,
        `https://practiceapi.geeksforgeeks.org/api/vr/problems/${slug}/submissions/`,
    ];
    const findCode = (value, depth) => {
        if (depth > 6 || !value)
            return null;
        if (typeof value === "string") {
            return value.includes("\n") && value.trim().length > 20 ? value : null;
        }
        if (Array.isArray(value)) {
            for (const item of value) {
                const hit = findCode(item, depth + 1);
                if (hit)
                    return hit;
            }
            return null;
        }
        if (typeof value === "object") {
            for (const field of ["code", "sub_code", "solution", "source", "user_code"]) {
                const direct = value[field];
                if (typeof direct === "string" && direct.trim().length > 20)
                    return direct;
            }
            for (const nested of Object.values(value)) {
                const hit = findCode(nested, depth + 1);
                if (hit)
                    return hit;
            }
        }
        return null;
    };
    const attempt = (i) => {
        if (i >= urls.length)
            return null;
        return fetch(urls[i], { credentials: "include" })
            .then((r) => (r.ok ? r.json() : null))
            .then((json) => findCode(json, 0) || attempt(i + 1))
            .catch(() => attempt(i + 1));
    };
    return attempt(0);
}
async function sourceViaTab(slug) {
    if (!slug || !chrome.tabs?.query || !chrome.scripting?.executeScript)
        return null;
    let tabs;
    try {
        tabs = await chrome.tabs.query({ url: ["*://*.geeksforgeeks.org/*"] });
    }
    catch {
        return null;
    }
    const tab = tabs.find((t) => Number.isInteger(t.id) && t.status === "complete") ||
        tabs.find((t) => Number.isInteger(t.id));
    if (!tab)
        return null;
    try {
        const frames = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            world: "MAIN",
            func: requestSubmissionsInPage,
            args: [String(slug)],
        });
        return frames?.[0]?.result || null;
    }
    catch {
        return null;
    }
}
export async function fetchSource(sub) {
    if (sub.source && String(sub.source).trim())
        return String(sub.source);
    const fromTab = await sourceViaTab(sub.slug);
    if (fromTab && fromTab.trim())
        return fromTab;
    return null;
}
export const PLATFORM = {
    name: "gfg",
    label: "GeeksforGeeks",
    problemKey: keyFor,
    async fetchMetadata(sub) {
        const slug = sub.slug || sub.problemSlug || "problem";
        const title = keyFor(sub);
        const difficulty = normalizeDifficulty(sub.difficulty);
        const language = sub.language || "C++";
        return {
            platform: "gfg",
            id: String(sub.id || slug),
            key: title,
            title,
            difficulty,
            language,
            ext: extFor(language),
            folder: difficulty,
            path: `geeksforgeeks/${difficulty}/${title}.${extFor(language)}`,
            url: sub.url || `https://www.geeksforgeeks.org/problems/${slug}/1`,
            tags: [difficulty],
        };
    },
    fetchSource,
};
